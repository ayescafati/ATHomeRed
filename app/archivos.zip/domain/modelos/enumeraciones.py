from __future__ import annotations
from enum import IntEnum

class DiaSemana(IntEnum):
    LUNES = 1
    MARTES = 2
    MIERCOLES = 3
    JUEVES = 4
    VIERNES = 5
    SABADO = 6
    DOMINGO = 7
