from __future__ import annotations
import uuid
from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import UniqueConstraint, ForeignKey, text
from sqlalchemy.dialects.postgresql import UUID, VARCHAR as Varchar
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import Base, SCHEMA
from .servicios import profesional_especialidad  # mantiene tabla puente especialidad

if TYPE_CHECKING:
    from .usuarios import UsuarioORM
    from .ubicacion import DireccionORM
    from .servicios import EspecialidadORM
    from .agenda import DisponibilidadORM
    from .publicaciones import PublicacionORM
    from .matriculas import MatriculaORM
    from .valoraciones import ValoracionORM
    from .paciente import PacienteORM

class ProfesionalORM(Base):
    __tablename__ = "profesional"
    __table_args__ = (
        UniqueConstraint("usuario_id", name="uq_profesional_usuario"),
        {"schema": SCHEMA},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, server_default=text("gen_random_uuid()")
    )
    usuario_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey(f"{SCHEMA}.usuario.id", ondelete="CASCADE"), nullable=False
    )

    # si direccion.id es int identity (recomendado para catálogos)
    direccion_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey(f"{SCHEMA}.direccion.id", ondelete="SET NULL")
    )

    activo: Mapped[bool] = mapped_column(default=True, nullable=False)
    verificado: Mapped[bool] = mapped_column(default=False, nullable=False)
    matricula: Mapped[Optional[str]] = mapped_column(Varchar(50))

    usuario: Mapped["UsuarioORM"] = relationship("UsuarioORM")
    direccion: Mapped[Optional["DireccionORM"]] = relationship("DireccionORM")

    especialidades: Mapped[List["EspecialidadORM"]] = relationship(
        "EspecialidadORM", secondary=profesional_especialidad, lazy="joined"
    )
    disponibilidades: Mapped[List["DisponibilidadORM"]] = relationship(
        "DisponibilidadORM", back_populates="profesional", cascade="all, delete-orphan"
    )
    publicaciones: Mapped[List["PublicacionORM"]] = relationship(
        "PublicacionORM", back_populates="profesional", cascade="all, delete-orphan"
    )
    matriculas: Mapped[List["MatriculaORM"]] = relationship(
        "MatriculaORM", back_populates="profesional", cascade="all, delete-orphan"
    )
    valoraciones: Mapped[List["ValoracionORM"]] = relationship(
        "ValoracionORM", back_populates="profesional", cascade="all, delete-orphan"
    )

class SolicitanteORM(Base):
    __tablename__ = "solicitante"
    __table_args__ = (
        UniqueConstraint("usuario_id", name="uq_solicitante_usuario"),
        {"schema": SCHEMA},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, server_default=text("gen_random_uuid()")
    )
    usuario_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey(f"{SCHEMA}.usuario.id", ondelete="CASCADE"), nullable=False
    )
    direccion_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey(f"{SCHEMA}.direccion.id", ondelete="SET NULL")
    )

    activo: Mapped[bool] = mapped_column(default=True, nullable=False)

    usuario: Mapped["UsuarioORM"] = relationship("UsuarioORM")

    # 1–1 actual: un solicitante tiene a lo sumo un paciente
    paciente: Mapped[Optional["PacienteORM"]] = relationship(
        "PacienteORM", back_populates="solicitante", uselist=False
    )
