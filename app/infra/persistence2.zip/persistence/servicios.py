from __future__ import annotations

from decimal import Decimal

from sqlalchemy import Table, Column, Integer, Numeric, Text, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, VARCHAR as Varchar
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, SCHEMA

# Especialidades y tabla puente profesional_especialidad


class EspecialidadORM(Base):
    __tablename__ = "especialidad"

    id_especialidad: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    nombre: Mapped[str] = mapped_column(Varchar(80), nullable=False, unique=True)
    descripcion: Mapped[str] = mapped_column(Text, nullable=False)
    tarifa: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)


profesional_especialidad = Table(
    "profesional_especialidad",
    Base.metadata,
    Column("profesional_id", UUID(as_uuid=True),
           ForeignKey(f"{SCHEMA}.profesional.id", ondelete="CASCADE"),
           primary_key=True),
    Column("especialidad_id", Integer,
           ForeignKey(f"{SCHEMA}.especialidad.id_especialidad", ondelete="CASCADE"),
           primary_key=True),
)
